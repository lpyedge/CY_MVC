﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("YUI Compressor .NET Library Nant Task")]
[assembly: AssemblyDescription("A Nant Task for a .NET port of the Yahoo! YUI Compressor project")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("715d7d57-0662-443d-8e18-348eeeac262d")]