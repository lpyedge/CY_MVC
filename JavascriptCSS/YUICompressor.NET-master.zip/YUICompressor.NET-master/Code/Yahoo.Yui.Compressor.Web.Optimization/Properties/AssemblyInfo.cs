﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("YUI Compressor .NET Library - Web Optimizations")]
[assembly: AssemblyDescription("A .NET port of the Yahoo! YUI Compressor project but leveraging the new System.Web.Optimizations bundle transforms.")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("4a88cb9e-8845-4128-9e09-ce89e43d0d78")]