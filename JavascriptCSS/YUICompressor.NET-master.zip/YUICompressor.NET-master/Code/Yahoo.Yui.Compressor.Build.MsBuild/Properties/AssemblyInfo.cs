﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("YUI Compressor .NET Library MsBuild Task")]
[assembly: AssemblyDescription("An MsBuild Task for a .NET port of the Yahoo! YUI Compressor project")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("c1364e8f-edc2-4e85-9fa4-2b0757a4b6bf")]