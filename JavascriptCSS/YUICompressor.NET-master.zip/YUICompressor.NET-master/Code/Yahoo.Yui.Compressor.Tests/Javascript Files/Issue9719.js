this.element
    .attr('style', '')
    .css({
        top: 0,
        left: 0,
        position: 'relative',
        float: 'left'
    });