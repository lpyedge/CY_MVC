﻿function test() {
    var number = 1;
    eval("alert('Hello world!');");
}