Strings = {
	IncorrectLogin: 'Felaktigt användarnamn eller lösenord. Försök igen!',
    ExpandAll: 'Visa allt',
    CollapseAll: 'Minimera',
    ViewInNormalMode: 'Tryck här för normalt läge'
};