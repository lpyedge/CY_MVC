﻿namespace Yahoo.Yui.Compressor
{
    public enum LoggingType
    {
        None,
        Info,
        Debug
    }
}