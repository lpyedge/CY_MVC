﻿namespace Yahoo.Yui.Compressor
{
    public enum CssCompressionType
    {
        None,
        StockYuiCompressor
    }
}