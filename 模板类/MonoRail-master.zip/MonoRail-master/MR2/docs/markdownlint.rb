all
exclude_rule 'MD010' # Hard tabs - too much example code has tabs
exclude_rule 'MD013' # Line length
exclude_rule 'MD033' # Inline HTML - for right-aligning an image
exclude_rule 'MD040' # Fenced code blocks should have a language specified