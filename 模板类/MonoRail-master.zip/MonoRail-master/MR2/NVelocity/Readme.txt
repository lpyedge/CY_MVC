
More information about NVelocity
can be found at http://www.castleproject.org/